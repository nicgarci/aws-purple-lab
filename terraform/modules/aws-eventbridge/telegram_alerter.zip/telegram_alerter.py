from urllib import request
import json

def lambda_handler(event, context):
    token = '8152216638:AAH0Wvm7nEuhr-hNhHOAmNwjZDbZtbVEozA'
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    alert_data = json.dumps(event, indent=2)
    data = {
        "chat_id": "-1004452229112",
        "text": alert_data
    }
    encoded_data = json.dumps(data).encode('utf-8')
    tg_req = request.Request(url, data=encoded_data, headers={'Content-Type': 'application/json'})
    request.urlopen(tg_req)